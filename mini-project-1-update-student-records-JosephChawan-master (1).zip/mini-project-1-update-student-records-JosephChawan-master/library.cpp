#include "library.h"

//Use this file to include the implementations of your functions.

void getOneStudent(ifstream& input, Student& s) {

} //end of getOneStudent

void displayAllStudents(const Student arr[], int n) {
  
} //end of displayAllStudents

int findStudent(const Student arr[], int n, const string& id) {
  return -1;
} //end of findStudent

void updateStudent(Student& s, int units, char letter) {

} //end of updateStudent

void sortByStartSession(Student arr[], int n) {
  
} //end of sortByStartSession