#include <iostream>
#include <fstream>
#include "catch.hpp"
#include "../library.h"

/* Tested functions:
void getOneStudent(ifstream& input, Student& s);
!! void displayAllStudents(const Student arr[], int n); UNTESTABLE!!
int findStudent(const Student arr[], int n, const string& str);
void updateStudent(Student& s, int units, char letter);
void sortByStartSession(Student arr[], int n);
*/

Student s1{"21800001","Mickey Mouse",4,4,2};
Student s2{"11912345","Donald Duck",3,3,3};
Student s3{"31810000","Minnie Mouse",6,3,2};


TEST_CASE("1: Test getOneStudent function", "[getOneStudent]"){
  ifstream fin("records.csv");
  Student s;

  if(!fin.is_open()){
    FAIL("Unable to open records.csv");
  }
  //get first record: 21800001,Mickey Mouse,4,4,2
  getOneStudent(fin, s);
  CHECK(s.ID == "21800123");
  CHECK(s.name == "Patrick Star");
  CHECK(s.unitsAttempted == 42);
  CHECK(s.unitsEarned == 36);
  CHECK(s.gpa == 2.85);

  //get second record: 11912345,Donald Duck,3,3,3
  getOneStudent(fin, s);
  CHECK(s.ID == "41912345");
  CHECK(s.name == "Squidward Tentacles");
  CHECK(s.unitsAttempted == 37);
  CHECK(s.unitsEarned == 37);
  CHECK(s.gpa == 3.26);

  fin.close();
}


TEST_CASE("2: Test findStudent", "[findStudent]"){
  Student arr[] = {s1,s2,s3};

  SECTION("Find existing students:"){
    CHECK(findStudent(arr, 3, "21800001") == 0);
    CHECK(findStudent(arr, 3, "11912345") == 1);
    CHECK(findStudent(arr, 3, "31810000") == 2);
  }

  SECTION("Test if student doesn't exist:"){
    CHECK(findStudent(arr, 3, "123") == -1);
  }
}


TEST_CASE("3: Test updateStudent", "[updateStudent]"){

  SECTION("Recieved A, 4 unit class; Original=4 attempted, 4 earned, 2 gpa"){
    updateStudent(s1, 4, 'A');
    CHECK(s1.gpa == 3);
    CHECK(s1.unitsEarned == 8);
    CHECK(s1.unitsAttempted == 8);
  }

  SECTION("Recieved F, 2 unit class; Original=6 attempted, 3 earned, 2 gpa"){
    updateStudent(s3, 2, 'F');
    CHECK(s3.gpa == 1.5);
    CHECK(s3.unitsEarned == 3);
    CHECK(s3.unitsAttempted == 8);
  }
}


TEST_CASE("4: Test sortByStartSession", "[sortByStartSession]"){
  Student arr[] = {s1,s2,s3};

  sortByStartSession(arr, 3);
  CHECK(arr[0].ID == "21800001");
  CHECK(arr[1].ID == "31810000");
  CHECK(arr[2].ID == "11912345");
}