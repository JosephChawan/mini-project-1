#include <iostream>
#include "library.h"
using namespace std;



int main() {
  //use this area to include the main flow of your program and make calls to the functions.
  cout << "Updating student records ..." << endl;
  return 0;
} 